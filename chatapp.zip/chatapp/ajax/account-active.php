<?php
session_start();
include("../includes/config.php");
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$myEmail = "mohatamimhaque7@gmail.com";
$appPassword = "tdgclidgdkmezvnr";
$yourname = 'ChatApp';

function code($length) {
    $characters = '0123456789';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
if(isset($_POST["user_id"])){
    $user_id= $_POST["user_id"];
    $str= $_POST["str"];
    $query = mysqli_query($con, "SELECT * FROM user WHERE id = '$user_id'");
    if(mysqli_num_rows($query) > 0){
        $row = mysqli_fetch_assoc($query);

     if($str == $row['activation_code']){
        $query = mysqli_query($con, "UPDATE user SET status = 0,activation_code='0' WHERE id = '$user_id'");
        echo 'Success';
    }
     else{
        echo "Code doesn't Matched";
     }
}
    else{
     echo 'failed';
}



}
if(isset($_POST["update"])){
    $user_id= $_POST["id"];
    $query = mysqli_query($con, "SELECT * FROM user WHERE id = '$user_id'");
    if(mysqli_num_rows($query) > 0){
        foreach($query as $row);
            $email = $row["email"];
             if(filter_var($email, FILTER_VALIDATE_EMAIL)){
                $mail = new PHPMailer(true);
                $name = $row['first_name'].' '.$row['last_name'];
                $code = code(6);
                try {
                    // Server settings
                    $mail->isSMTP();                                      
                    $mail->Host = 'smtp.gmail.com';                     
                    $mail->SMTPAuth = true;                              
                    $mail->Username = $myEmail;             
                    $mail->Password = $appPassword;                
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;  
                    $mail->Port = 587;                                   
                
                    $mail->setFrom($myEmail, $yourname);
                    $mail->addAddress($email, $name);  
                
                    $mail->isHTML(true);
                    $mail->Subject = $code.' is your '.$yourname.' account recovery code';                                
                    $mail->Body = '
                    <!DOCTYPE html>
                    <html>
                    <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    </head>
                    <body style="font-family: Arial, sans-serif; color: #333; margin: 0; padding: 0;">
                    <div style="padding: 20px;">
                        <p>Hi '.$name.',</p>
                        <p>We received a request to reset your '.$yourname.' password.</p>
                        <p>Enter the following password reset code:</p>
                        <div style="background-color: #f1f4f8; border: 1px solid #c8d1dc; padding: 15px; display: inline-block; margin: 10px 0; font-size: 24px; font-weight: bold; border-radius: 5px; text-align: center;">
                        '.$code.'
                        </div>
                    </div>
                    </body>
                    </html>';

                    $mail->AltBody = 'Hi '.$name.', We received a request to reset your '.$yourname.' password. Your reset code is: '.$code;
                    if($mail->send()){
                        $query = mysqli_query($con, "UPDATE user SET activation_code = '$code' WHERE id = '$user_id'");
                        echo "Code sent Successfully!!";
                    }else{
                        echo "something error!!";
                    }
                }catch (Exception $e) {
                    echo "something error!!";
                }
            
        }else{
            echo "You are not registered!!";
        }
    }else{
        echo "Enter a valid email!!";
    }
}


?>
