
<div class="react">
    <div class="options">
        <span class="reactions">
          <div class="icon-container">
            <span data-popup="Like" data-i="1" class="like reaction"></span>
          </div>
          <div class="icon-container">
            <span data-popup="Love" data-i="2" class="love reaction"></span>
          </div>
          <div class="icon-container">
            <span data-popup="Thankful" data-i="3" class="thankful reaction"></span>
          </div>
          <div class="icon-container">
            <span data-popup="Haha" data-i="4" class="haha reaction"></span>
          </div>
          <div class="icon-container">
            <span data-popup="Wow" data-i="5" class="wow reaction"></span>
          </div>
          <div class="icon-container">
            <span data-popup="Sad" data-i="6" class="sad reaction"></span>
          </div>
          <div class="icon-container">
            <span data-popup="Angry" data-i="7" class="angry reaction"></span>
          </div>
        </span>
      
        <span class="button">
          Like
        </span>
      </div>
       
      </div>
